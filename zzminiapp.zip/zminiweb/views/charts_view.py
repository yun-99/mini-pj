from flask import Blueprint
from flask import render_template, redirect, url_for
from flask import request, session
import json


charts_bp = Blueprint('charts', __name__, url_prefix="/charts")


####################################### chart start #######################################

@charts_bp.route("/kbCharts", methods=['GET'])
def kb():
    return render_template('charts/kbCharts.html')


@charts_bp.route("/ysCharts", methods=['GET'])
def ys():
    return render_template('charts/ysCharts.html')


@charts_bp.route("/yhCharts", methods=['GET'])
def yh():
    return render_template('charts/yhCharts.html')
@charts_bp.route('/')
def chart():
    # 데이터 예시
    age_death_rate = [
        {"연령": "10대", "사망률": 0.1},
        {"연령": "20대", "사망률": 0.2},
        {"연령": "30대", "사망률": 0.4},
        {"연령": "40대", "사망률": 0.8},
        {"연령": "50대", "사망률": 1.2},
    ]

    chart_data = json.dumps([[i, row["사망률"]] for i, row in enumerate(age_death_rate)])
    labels = json.dumps([row["연령"] for row in age_death_rate])

    return render_template('chart.html', chart_data=chart_data, labels=labels)


    # chart.html에 데이터 넘김
    return render_template('chart.html', chart_data=chart_data, labels=labels)

####################################### chart end #######################################

